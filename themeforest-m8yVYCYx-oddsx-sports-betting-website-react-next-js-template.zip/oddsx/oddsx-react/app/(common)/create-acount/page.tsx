import CreateAcount from '@/components/Pages/CreateAcount/CreateAcount'
import LogRegHeader from '@/components/Shared/LogRegHeader'

export default function page() {
    return (
        <>
            <LogRegHeader />
            <CreateAcount />
        </>
    )
}
